# Employee-Payroll-Management-System
This project is basically used by an Employee to First Enter their login details and Each Employee has certain records 
which contain information related to Employee which is saved in the database and Employee Can do certain operation 
such as insert, update and delete in the database and calculate salary
# Login
![1](https://user-images.githubusercontent.com/33680160/49326900-44e24300-f583-11e8-9431-4275c823d46b.png)
# Main
![2](https://user-images.githubusercontent.com/33680160/49326901-44e24300-f583-11e8-940f-a5f0b3187f90.png)
# Add Employee
![3](https://user-images.githubusercontent.com/33680160/49327315-5d099080-f58a-11e8-932f-c2cd60ad3f6e.png)
# Update Employee
![4](https://user-images.githubusercontent.com/33680160/49327316-5da22700-f58a-11e8-9067-4f9742b02b52.png)
# Delete Employee
![5](https://user-images.githubusercontent.com/33680160/49327317-5da22700-f58a-11e8-9785-fe4e33baa146.png)
# Employee
![6](https://user-images.githubusercontent.com/33680160/49326905-46137000-f583-11e8-9e32-f69853329931.png)
# Allowance 
![7](https://user-images.githubusercontent.com/33680160/49327318-5e3abd80-f58a-11e8-98a4-a15db21b2dea.png)
# Search Employee
![8](https://user-images.githubusercontent.com/33680160/49327319-5e3abd80-f58a-11e8-9ea1-eb9a15224d23.png)
# Update Salary in (%)
![9](https://user-images.githubusercontent.com/33680160/49327320-5e3abd80-f58a-11e8-8ea0-e964a2a30c73.png)
# Update Salary in (amount)
![10](https://user-images.githubusercontent.com/33680160/49327497-e7eb8a80-f58c-11e8-9b93-5015a98a56b4.png)
# Deduction
![11](https://user-images.githubusercontent.com/33680160/49327498-e8842100-f58c-11e8-9c7a-c7410e98e909.png)








